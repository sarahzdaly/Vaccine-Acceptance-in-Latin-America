### Replication File for Argote et al. (2021): The shot, the message, and the messenger. Published in npj Vaccines ####
library(cregg)
library(devtools)
library(forcats)
library(car)
library(estimatr)
library(haven)
library(lfe)
library(tidyverse)
library(stargazer)
library(coefplot)
library(ggplot2)
library(foreign)
 
# Load Data and Conjoint Function 
hesitancy_long <- read.csv("argote_et_al_for_replication.csv")
source("00_table_functions_conjoint_all.R")

#### Figure 1 and Figure 2 ####  
RHS_conjoint_full <- "distrib_ngo + distrib_army + endorse_relig + endorse_mayor + endorse_pres + endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"
 
conjoint_outcomes <- c("willing_vaccine", "quickly_post_1_text_reversed")

conjoint_full <- lapply(1:length(conjoint_outcomes), function(y)
  felm(as.formula(paste0(conjoint_outcomes[y], " ~ ",
                         RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
       data = hesitancy_long,
       weights = hesitancy_long$w_conjoint,
       cmethod = 'reghdfe')
)

predictornames_figure <- c(
                           efficacy_text       = "(Efficacy)",
                           efficacy_95         = "95% (Pfizer)",
                           efficacy_91         = "91% (Gamaleya)",
                           efficacy_78         = "78% (Sinovac)",
                           efficacy_70         = "70% (Astrazeneca)",
                           efficacy_50         = "50% (Sinovac)",
                           efficacy_           = "No Efficacy Information",
                           uptake_text         = "(Uptake)",
                           uptake_75           = "75%",
                           uptake_50           = "50%",
                           uptake_25           = "25%",
                           uptake_1            = "1%",
                           uptake_             = "No Uptake Information",
                           vaccine_text        = "(Producer)",
                           vaccine_gamaleya    = "Gamaleya",
                           vaccine_pfizer      = "Pfizer",
                           vaccine_astrazeneca = "Astrazeneca",
                           vaccine_sinovac     = "Sinovac",
                           vaccine_            = "No Producer Information",
                           endorse_text        = "(Endorser)",
                           endorse_leftnews    = "Left Newspaper",
                           endorse_rightnews   = "Right Newspaper",
                           endorse_pres        = "President",
                           endorse_mayor       = "Mayor",
                           endorse_            = "Medical Association",
                           endorse_relig       = "Religious Leader",
                           distrib_text        = "(Distributor)",
                           distrib_army        = "Armed Forces",
                           distrib_ngo         = "Civil Society",
                           distrib_            = "National Health System"
)

#conjoint_outcomes_label_long <- c("Willingness to Take this Vaccine",
                                #  "Months Would Wait Before Taking this Vaccine (Reversed Scale)")

coef_plot_data <- lapply(1:length(conjoint_outcomes), function(y)
    data.frame(
      estimate = c(
        conjoint_full[[y]]$coefficients[,1],
        distrib_ = 0,
        endorse_ = 0,
        vaccine_ = 0,
        uptake_ = 0,
        efficacy_ = 0,
        distrib_text = NA,
        endorse_text = NA,
        vaccine_text = NA,
        uptake_text = NA,
        efficacy_text = NA
      ),
      std.error = c(
        summary(conjoint_full[[y]], robust = TRUE)$coefficients[, 'Cluster s.e.'],
        distrib_ = 0,
        endorse_ = 0,
        vaccine_ = 0,
        uptake_ = 0,
        efficacy_ = 0,
        distrib_text = NA,
        endorse_text = NA,
        vaccine_text = NA,
        uptake_text = NA,
        efficacy_text = NA
      )
    )
  )

for (y in 1:length(conjoint_outcomes)) {
 coef_plot_data[[y]]$level <- factor(row.names(coef_plot_data[[y]]),
                                    levels = rev(c(
                                              "distrib_text",
                                              "distrib_ngo",
                                              "distrib_army",
                                              "distrib_",
                                              "endorse_text",
                                              "endorse_pres",
                                              "endorse_mayor",
                                              "endorse_rightnews",
                                              "endorse_leftnews",
                                              "endorse_relig",
                                              "endorse_",
                                              "vaccine_text",
                                              "vaccine_astrazeneca",
                                              "vaccine_gamaleya",
                                              "vaccine_pfizer",
                                              "vaccine_sinovac",
                                              "vaccine_",
                                              "efficacy_text",
                                              "efficacy_95",
                                              "efficacy_91",
                                              "efficacy_78",
                                              "efficacy_70",
                                              "efficacy_50",
                                              "efficacy_",
                                              "uptake_text",
                                              "uptake_75",
                                              "uptake_50",
                                              "uptake_25",
                                              "uptake_1",
                                              "uptake_"
 )))
 coef_plot_data[[y]]$upper <- coef_plot_data[[y]]$estimate + 1.96*coef_plot_data[[y]]$std.error
 coef_plot_data[[y]]$lower <- coef_plot_data[[y]]$estimate - 1.96*coef_plot_data[[y]]$std.error
 coef_plot_data[[y]]$Feature <- sub("_.*", "", coef_plot_data[[y]]$level)
 coef_plot_data[[y]]$Feature <- case_when(
   coef_plot_data[[y]]$Feature == "distrib" ~ "Distributor",
   coef_plot_data[[y]]$Feature == "efficacy" ~ "Efficacy",
   coef_plot_data[[y]]$Feature == "endorse" ~ "Endorser",
   coef_plot_data[[y]]$Feature == "uptake" ~ "Uptake",
   coef_plot_data[[y]]$Feature == "vaccine" ~ "Producer"
 )
 coef_plot_data[[y]]$Feature <- factor(coef_plot_data[[y]]$Feature,
                                       levels = c("Distributor", "Endorser", "Producer", "Efficacy", "Uptake"))
}

conjoint_main_plots <- lapply(1:length(conjoint_outcomes), function(y)
ggplot(coef_plot_data[[y]], aes(x = estimate, y = level, color = Feature)) +
  geom_point() +
  geom_pointrange(aes(xmin = lower, xmax = upper)) +
  geom_vline(xintercept = 0, color = "grey", linetype = "dashed") +
  scale_y_discrete(labels = predictornames_figure) +
  xlab("Average Marginal Component Effect") +
  ylab("") +
 # ggtitle(conjoint_outcomes_label_long[y]) +
  theme_bw() +
  theme(legend.position = "bottom",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
    axis.text.y = element_text(face = rev(
    c("bold",
      rep("plain", 3),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5)))))
)

for (y in 1:length(conjoint_main_plots)) {
  pdf(paste0("main_conjoint_", conjoint_outcomes[y], ".pdf"))
  print(conjoint_main_plots[[y]])
  dev.off()
}

#### Figure 3 #### 
RHS_trust_conjoint <- "trust_orgs_3*distrib_ngo + trust_orgs_1*distrib_army + trust_persons_insts_7*endorse_relig + trust_persons_insts_2*endorse_mayor + trust_persons_insts_1*endorse_pres + trust_persons_insts_6*endorse_rightnews + trust_persons_insts_5*endorse_leftnews + trust_country_govs_1*vaccine_sinovac + trust_country_govs_4*vaccine_astrazeneca + trust_country_govs_2*vaccine_pfizer + trust_country_govs_3*vaccine_pfizer + trust_country_govs_5*vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"

conjoint_full_trust <- lapply(1:length(conjoint_outcomes), function(y)
  felm(as.formula(paste0(conjoint_outcomes[y], " ~ ",
                         RHS_trust_conjoint, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
       data = hesitancy_long,
       weights = hesitancy_long$w_conjoint,
       cmethod = 'reghdfe')
)


#conjoint_outcomes_label_long <- c("Heterogeneous Effects on Willingness by Trust",
                #                  "Heterogeneous Effects on Months to Vaccination by Trust")

colors <- c("blue", "purple")

conjoint_main_trust_plots <- lapply(1:length(conjoint_outcomes), function(y)
  coefplot(conjoint_full_trust[[y]], 
           coefficients=c("trust_orgs_3:distrib_ngo",
                          "trust_orgs_1:distrib_army",
                          "trust_persons_insts_7:endorse_relig",
                          "trust_persons_insts_2:endorse_mayor",
                          "trust_persons_insts_1:endorse_pres",
                          "trust_persons_insts_6:endorse_rightnews",
                          "trust_persons_insts_5:endorse_leftnews",
                          "trust_country_govs_1:vaccine_sinovac", 
                          "trust_country_govs_4:vaccine_astrazeneca",
                          "trust_country_govs_2:vaccine_pfizer",
                          "vaccine_pfizer:trust_country_govs_3",
                          "trust_country_govs_5:vaccine_gamaleya"),
           sds = summary(conjoint_full_trust[[y]], robust = TRUE)$coefficients[,'Cluster s.e.'],
           innerCI = 0,
           intercept = TRUE,
           color = colors[y],
           xlab = "Coefficient on the Interaction Term", 
           ylab = "") + 
          # ylab = "Coefficient on the Interaction Term") + 
    scale_y_discrete(labels = c("Civil Society x Trust",
                                "Armed Forces x Trust",
                                "Religious Leader x Trust",
                                "Mayor x Trust",
                                "President x Trust",
                                "Right-Wing Newspaper x Trust",
                                "Left-Wing Newspaper x Trust",
                                "Sinovac x Trust in China",
                                "Astrazeneca x Trust in UK",
                                "Pfizer x Trust in Biden",
                                "Pfizer x Trust in Trump",
                                "Gamaleya x Trust in Russia")) + 
  #  ggtitle(conjoint_outcomes_label_long[y]) + 
    ggtitle("") + 
    theme_bw() +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

for (y in 1:length(conjoint_main_trust_plots)) {
  pdf(paste0("main_conjoint_trust_", conjoint_outcomes[y], ".pdf"))
  print(conjoint_main_trust_plots[[y]])
  dev.off()
}

#### All Appendix Tables ####

## Table A2 
hesitancy_long <- subset(hesitancy_long, hesitancy_pre > 0) 
RHS_conjoint_balance <- "distrib_ngo + distrib_army + endorse_relig + endorse_mayor + endorse_pres + 
endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_gamaleya +
uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"

predictornames_balance <- c("Distributor: Civil Society",
                            "Distributor: Armed Forces",
                            "Endorser: Religious Leader",
                            "Endorser: Mayor",
                            "Endorser: President",
                            "Endorser: Right Newspaper",
                            "Endorser: Left Newspaper", 
                            "Producer: Sinovac", 
                            "Producer: Astrazeneca", 
                            "Producer: Pfizer",  
                            "Producer: Gamaleya",
                            "1\\% Uptake",
                            "25\\% Uptake",
                            "50\\% Uptake",
                            "75\\% Uptake", 
                            "Efficacy Concern", 
                            "50\\% Efficacy",
                            "70\\% Efficacy",
                            "78\\% Efficacy",
                            "91\\% Efficacy",
                            "95\\% Efficacy") 


conjoint_outcomes <- c("age_bin_num", "male", "education_enc", "hesitancy_pre", "std_months_pre")
RHS_list <- list(RHS_conjoint_balance)
rounds_list <- c("1", "1", "1", "1", "1") 
predictor_names_list <- list(predictornames_balance)
conjoint_outcomes_label <- c("Age Bin", "Gender", "Education", "Pre-Treatment Hesitancy", "Pre-Treatment Months")
conjoints_het_names <- c("_A2_balance")

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint_balance(RHS = RHS_list[[i]],
                      outcome_vars = conjoint_outcomes,
                      round = rounds_list[i],
                      outcome_labels = conjoint_outcomes_label,
                      treatment_labels = predictor_names_list[[i]],
                      table_name = paste0("table_", i, "_", conjoints_het_names[[i]]))
}

## Table A6 
RHS_trust_conjoint <- "trust_orgs_3*distrib_ngo + trust_orgs_1*distrib_army + trust_persons_insts_7*endorse_relig + trust_persons_insts_2*endorse_mayor + trust_persons_insts_1*endorse_pres + trust_persons_insts_6*endorse_rightnews + trust_persons_insts_5*endorse_leftnews + trust_country_govs_1*vaccine_sinovac + trust_country_govs_4*vaccine_astrazeneca + trust_country_govs_2*vaccine_pfizer + trust_country_govs_3*vaccine_pfizer + trust_country_govs_5*vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"

predictornames_trust <- c(  "Trust Civil Society",
                            "Distributor: Civil Society",
                            "Trust Armed Forces", 
                            "Distributor: Armed Forces",
                            "Trust Religious Leader", 
                            "Endorser: Religious Leader",
                            "Trust Mayor", 
                            "Endorser: Mayor",
                            "Trust President",
                            "Endorser: President",
                            "Trust R News", 
                            "Endorser: Right Newspaper",
                            "Trust L News", 
                            "Endorser: Left Newspaper", 
                            "Trust China", 
                            "Producer: Sinovac", 
                            "Trust UK", 
                            "Producer: Astrazeneca", 
                            "Trust US - Biden", 
                            "Producer: Pfizer", 
                            "Trust US - Trump",
                            "Trust Russia", 
                            "Producer: Gamaleya",
                            "1\\% Uptake",
                            "25\\% Uptake",
                            "50\\% Uptake",
                            "75\\% Uptake", 
                            "50\\% Efficacy",
                            "70\\% Efficacy",
                            "78\\% Efficacy",
                            "91\\% Efficacy",
                            "95\\% Efficacy",
                            "Distributor: Civil Society $\\times$ Trust",
                            "Distributor: Army $\\times$ Trust",
                            "Endorser: Religious Leader $\\times$ Trust", 
                            "Endorser: Mayor $\\times$ Trust", 
                            "Endorser: President $\\times$ Trust",
                            "Endorser: R News $\\times$ Trust",
                            "Endorser: L News $\\times$ Trust",
                            "Producer: Sinovac $\\times$ Trust China",
                            "Producer: Atrazeneca $\\times$ Trust UK",
                            "Producer: Pfizer $\\times$ Trust US - Trump",
                            "Producer: Pfizer $\\times$ Trust UK - Biden",
                            "Producer: Gamaleya $\\times$ Trust Russia") 


conjoint_outcomes <- c("willing_vaccine", "quickly_post_1_text_reversed")
conjoint_outcomes_label <- c("Willing", "Months (Rev)")

RHS_list <- list(RHS_trust_conjoint) 

rounds_list <- c("full") 

predictor_names_list <- list(predictornames_trust) 

conjoints_het_names <- c("A6_trust") 

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint(RHS = RHS_list[[i]],
                      outcome_vars = conjoint_outcomes,
                      round = rounds_list[i],
                      outcome_labels = conjoint_outcomes_label,
                      treatment_labels = predictor_names_list[[i]],
                      table_name = paste0("table_", i, "_", conjoints_het_names[[i]]))
}


## Tables A3, A5, A9, A7 
RHS_conjoint_basic <- "distrib_ngo + distrib_army + endorse_relig + endorse_mayor + endorse_pres + endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_pfizer + vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"
RHS_conjoint_education_enc <- "education_enc*distrib_ngo + education_enc*distrib_army + education_enc*endorse_relig + education_enc*endorse_mayor + education_enc*endorse_pres + education_enc*endorse_rightnews + education_enc*endorse_leftnews + education_enc*vaccine_sinovac + education_enc*vaccine_astrazeneca + education_enc*vaccine_pfizer  + education_enc*vaccine_gamaleya + education_enc*uptake_1 + education_enc*uptake_25 + education_enc*uptake_50 + education_enc*uptake_75 + education_enc*efficacy_50 + education_enc*efficacy_70 + education_enc*efficacy_78 + education_enc*efficacy_91 + education_enc*efficacy_95"
RHS_conjoint_copartisan <- "distrib_ngo + distrib_army + endorse_relig + vote_mayor*endorse_mayor + vote_president*endorse_pres + endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_pfizer + vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"

{
  
  predictornames_basic <- c("Distributor: Civil Society",
                            "Distributor: Armed Forces",
                            "Endorser: Religious Leader",
                            "Endorser: Mayor",
                            "Endorser: President",
                            "Endorser: Right Newspaper",
                            "Endorser: Left Newspaper", 
                            "Producer: Sinovac", 
                            "Producer: Astrazeneca", 
                            "Producer: Pfizer",  
                            "Producer: Gamaleya",
                            "1\\% Uptake",
                            "25\\% Uptake",
                            "50\\% Uptake",
                            "75\\% Uptake",
                            "50\\% Efficacy",
                            "70\\% Efficacy",
                            "78\\% Efficacy",
                            "91\\% Efficacy",
                            "95\\% Efficacy" 
  )


  predictornames_education <- c("Education", 
                              "Distributor: Civil Society",
                              "Distributor: Armed Forces",
                              "Endorser: Religious Leader",
                              "Endorser: Mayor",
                              "Endorser: President",
                              "Endorser: Right Newspaper",
                              "Endorser: Left Newspaper", 
                              "Producer: Sinovac", 
                              "Producer: Astrazeneca", 
                              "Producer: Pfizer",  
                              "Producer: Gamaleya",
                              "1\\% Uptake",
                              "25\\% Uptake",
                              "50\\% Uptake",
                              "75\\% Uptake",
                              "50\\% Efficacy",
                              "70\\% Efficacy",
                              "78\\% Efficacy",
                              "91\\% Efficacy",
                              "95\\% Efficacy", 
                              "Education x Dist.: Civil Society",
                              "Education x Dist.: Armed Forces",
                              "Education x End.: Religious Leader",
                              "Education x End.: Mayor",
                              "Education x End.: President",
                              "Education x End.: Right Newspaper",
                              "Education x End.: Left Newspaper", 
                              "Education x Prod.: Sinovac", 
                              "Education x Prod.: Astrazeneca", 
                              "Education x Prod.: Pfizer",  
                              "Education x Prod.: Gamaleya",
                              "Education x 1\\% Uptake",
                              "Education x 25\\% Uptake",
                              "Education x 50\\% Uptake",
                              "Education x 75\\% Uptake",
                              "Education x 50\\% Efficacy",
                              "Education x 70\\% Efficacy",
                              "Education x 78\\% Efficacy",
                              "Education x 91\\% Efficacy",
                              "Education x 95\\% Efficacy") 
  
  predictornames_vote        <- c("Distributor: Civil Society",
                                  "Distributor: Armed Forces",
                                  "Endorser: Religious Leader",
                                  "Vote Mayor",
                                  "Endorser: Mayor",
                                  "Vote President",
                                  "Endorser: President",
                                  "Endorser: Right Newspaper",
                                  "Endorser: Left Newspaper", 
                                  "Producer: Sinovac", 
                                  "Producer: Astrazeneca", 
                                  "Producer: Pfizer", 
                                  "Producer: Gamaleya",
                                  "1\\% Uptake",
                                  "25\\% Uptake",
                                  "50\\% Uptake",
                                  "75\\% Uptake",
                                  "50\\% Efficacy",
                                  "70\\% Efficacy",
                                  "78\\% Efficacy",
                                  "91\\% Efficacy",
                                  "95\\% Efficacy",
                                  "Vote Mayor $\\times$ Mayor Endorse",
                                  "Vote President $\\times$ President Endorse")

}


conjoint_outcomes <- c("willing_vaccine", "quickly_post_1_text_reversed", "conjoint_mechanism_prop", "conjoint_mechanism_sick", "conjoint_mechanism_harm", "conjoint_mechanism_help")
conjoint_outcomes_label <- c("Willing", "Months (Rev)", "Stop Propagation", "Not Get COVID", "Wouldn't Harm", "Gov Help")

RHS_list <- list(RHS_conjoint_basic, 
                 RHS_conjoint_basic, 
                 RHS_conjoint_education_enc,
                 RHS_conjoint_copartisan
                 
) 

rounds_list <- c("full", 
                 "1", 
                 "full", 
                 "full", ) 

predictor_names_list <- list(predictornames_basic,
                             predictornames_basic,
                             predictornames_education,
                             predictornames_vote
) 

conjoints_het_names <- c("A3_basic", "A5_firstround", "A7_copartisan", "A8_education") 

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint(RHS = RHS_list[[i]],
                      outcome_vars = conjoint_outcomes,
                      round = rounds_list[i],
                      outcome_labels = conjoint_outcomes_label,
                      treatment_labels = predictor_names_list[[i]],
                      table_name = paste0("table_", i, "_", conjoints_het_names[[i]]))
}

## Table A4 
RHS_list <- list(RHS_conjoint_basic)
rounds_list <- c("full") 
predictor_names_list <- list(predictornames_basic)
conjoints_het_names <- c("_A4_confidence_intervals") 

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint_ci(RHS = RHS_list[[i]],
                               outcome_vars = conjoint_outcomes,
                               round = rounds_list[i],
                               outcome_labels = conjoint_outcomes_label,
                               treatment_labels = predictor_names_list[[i]],
                               table_name = paste0("table_", i, "_", conjoints_het_names[[i]]))
}

## Table A8
catholic <- subset(hesitancy_long, religion == 1)
evangelical <- subset(hesitancy_long, religion == 3)
RHS_list <- list(RHS_conjoint_endorser_trust) 

rounds_list <- c("full") 

predictor_names_list <- list(predictornames_endorsers) 

conjoints_table_names <- c("catholic_subset") 

for (i in 1:length(conjoints_table_names)) {
  make_table_conjoint_cath(RHS = RHS_list[[i]],
                      outcome_vars = conjoint_outcomes,
                      round = rounds_list[i],
                      outcome_labels = conjoint_outcomes_label,
                      treatment_labels = predictor_names_list[[i]],
                      table_name = paste0("table_A7_", i, "_", conjoints_table_names[[i]]))
}

conjoints_table_names <- c("evangelical_subset") 

for (i in 1:length(conjoints_table_names)) {
  make_table_conjoint_evangelical(RHS = RHS_list[[i]],
                               outcome_vars = conjoint_outcomes,
                               round = rounds_list[i],
                               outcome_labels = conjoint_outcomes_label,
                               treatment_labels = predictor_names_list[[i]],
                               table_name = paste0("table_A7_", i, "_", conjoints_table_names[[i]]))
}

hesitancy_long$catholic <- ifelse(hesitancy_long$religion == 1, 1, 0)
hesitancy_long$evangelical <- ifelse(hesitancy_long$religion == 3, 1, 0)

RHS_co_relig_catholic <- "distrib_ngo + distrib_army  + catholic*endorse_relig + endorse_pres + endorse_mayor + endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"
RHS_co_relig_evangelical <- "distrib_ngo + distrib_army  + evangelical*endorse_relig + endorse_pres + endorse_mayor + endorse_rightnews + endorse_leftnews + vaccine_sinovac + vaccine_astrazeneca + vaccine_pfizer + vaccine_gamaleya + uptake_1 + uptake_25 + uptake_50 + uptake_75 + efficacy_50 + efficacy_70 + efficacy_78 + efficacy_91 + efficacy_95"

{
  names_co_relig <- c(     "Distributor: Civil Society",
                           "Distributor: Armed Forces",  
                           "Co-Religious", 
                           "Endorser: Religious Leader",   
                           "Endorser: President",
                           "Endorser: Mayor", 
                           "Endorser: Right Newspaper",
                           "Endorser: Left Newspaper",
                           "Producer: Sinovac",
                           "Producer: Astrazeneca",
                           "Producer: Pfizer",
                           "Producer: Gamaleya",
                           "1\\% Uptake",
                           "25\\% Uptake",
                           "50\\% Uptake",
                           "75\\% Uptake",
                           "50\\% Efficacy",
                           "70\\% Efficacy",
                           "78\\% Efficacy",
                           "91\\% Efficacy",
                           "95\\% Efficacy",
                           "Co-Religious X Religious Endorsement"
  ) 
}

RHS_list <- list(RHS_co_relig_catholic, RHS_co_relig_evangelical)
rounds_list <- c("full", "full") 
predictor_names_list <- list(names_co_relig, names_co_relig)
conjoints_table_names <- c("co_relig_catholic", "co_relig_evangelical") 

for (i in 1:length(conjoints_table_names)) {
  make_table_conjoint(RHS = RHS_list[[i]],
                                  outcome_vars = conjoint_outcomes,
                                  round = rounds_list[i],
                                  outcome_labels = conjoint_outcomes_label,
                                  treatment_labels = predictor_names_list[[i]],
                                  table_name = paste0("table_A7_", i, "_", conjoints_table_names[[i]]))
}

## Table A10 
hesitancy_long$most_hesitant <- ifelse(hesitancy_long$std_months_pre > 1.6, 1, 0)
most_hes <- subset(hesitancy_long, most_hesitant == 1)
not_most_hes <- subset(hesitancy_long, most_hesitant == 0)

conjoint_outcomes <- c("willing_vaccine", "quickly_post_1_text_reversed")
RHS_list <- list(RHS_conjoint_basic)
rounds_list <- c("full") 
predictor_names_list <- list(predictornames_basic)
conjoint_outcomes_label <- c("Willing", "Months (Rev)") 
conjoints_het_names <- c("most_hes") 

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint_most_hes(RHS = RHS_list[[i]],
                                   outcome_vars = conjoint_outcomes,
                                   round = rounds_list[i],
                                   outcome_labels = conjoint_outcomes_label,
                                   treatment_labels = predictor_names_list[[i]],
                                   table_name = paste0("table_A9_", i, "_", conjoints_het_names[[i]]))
}

conjoints_het_names <- c("not_most_hes") 

for (i in 1:length(conjoints_het_names)) {
  make_table_conjoint_not_most_hes(RHS = RHS_list[[i]],
                               outcome_vars = conjoint_outcomes,
                               round = rounds_list[i],
                               outcome_labels = conjoint_outcomes_label,
                               treatment_labels = predictor_names_list[[i]],
                               table_name = paste0("table_A9_", i, "_", conjoints_het_names[[i]]))
}


#### By-Country Conjoint Results ####
argentina <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                                    RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
                  data = subset(hesitancy_long, country == "Argentina"),
                  weights = subset(hesitancy_long, country == "Argentina")$w_conjoint,
                  cmethod = 'reghdfe')

brazil <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                                 RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
               data = subset(hesitancy_long, country == "Brasil"),
               weights = subset(hesitancy_long, country == "Brasil")$w_conjoint,
               cmethod = 'reghdfe')

chile <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                                RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
              data = subset(hesitancy_long, country == "Chile"),
              weights = subset(hesitancy_long, country == "Chile")$w_conjoint,
              cmethod = 'reghdfe')

colombia <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                                   RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
                 data = subset(hesitancy_long, country == "Colombia"),
                 weights = subset(hesitancy_long, country == "Colombia")$w_conjoint,
                 cmethod = 'reghdfe')

mexico <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                                 RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
               data = subset(hesitancy_long, country == "México"),
               weights = subset(hesitancy_long, country == "México")$w_conjoint,
               cmethod = 'reghdfe')


peru <- felm(as.formula(paste0(conjoint_outcomes[1], " ~ ",
                               RHS_conjoint_full, " | as.factor(responseid) + as.factor(round) |
                         0 | responseid")),
             data = subset(hesitancy_long, country == "Perú"),
             weights = subset(hesitancy_long, country == "Perú")$w_conjoint,
             cmethod = 'reghdfe')

argentina_plot <- coefplot(argentina, 
                         sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                         intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

argentina_plot

brazil_plot <- coefplot(brazil, 
                           sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                           intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

brazil_plot

chile_plot <- coefplot(chile, 
                           sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                           intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

chile_plot

colombia_plot <- coefplot(colombia, 
                           sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                           intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

colombia_plot

mexico_plot <- coefplot(mexico, 
                           sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                           intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

mexico_plot

peru_plot <- coefplot(peru, 
                           sds = summary(colombia, robust = TRUE)$coefficients[,'Cluster s.e.'],
                           intercept = TRUE) + 
  scale_y_discrete(labels = predictornames_figure) +
  ggtitle(conjoint_outcomes_label_long[1])

peru_plot

#### Hesitancy Plots - LAPOP #### 
argentina_2019 <- read_dta("lapop_argentina_2019.dta")
brazil_2019 <- read_dta("lapop_brazil_2019.dta")
chile_2019 <- read_dta("lapop_chile_2019.dta")
colombia_2019 <- read_dta("lapop_colombia_2019.dta")
mexico_2019 <- read_dta("lapop_mexico_2019.dta")
peru_2019 <- read_dta("lapop_peru_2019.dta")
  
### Argentina 
small_argentina <- data.frame(argentina_2019$pais, argentina_2019$b12, argentina_2019$b21a, argentina_2019$b32, argentina_2019$mil10a, argentina_2019$mil10e) 
colnames(small_argentina) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_argentina$china_trust_clean <- 5 - small_argentina$china_trust
small_argentina$us_trust_clean <- 5 - small_argentina$us_trust 
small_argentina$army_trust <- (4*(small_argentina$army_trust))/7 
small_argentina$president_trust <- (4*(small_argentina$president_trust))/7 
small_argentina$muni_trust <- (4*(small_argentina$muni_trust))/7 

small_argentina$army_trust <- ifelse(small_argentina$army_trust < 1, 1, small_argentina$army_trust)
small_argentina$president_trust <- ifelse(small_argentina$president_trust < 1, 1, small_argentina$president_trust)
small_argentina$muni_trust <- ifelse(small_argentina$muni_trust < 1, 1, small_argentina$muni_trust)

small_argentina$us_trust <- NULL
small_argentina$china_trust <- NULL 
small_argentina$pais <- "Argentina"
small_argentina$country <- NULL  

small_argentina <- subset(small_argentina, !is.na(army_trust))
small_argentina <- subset(small_argentina, !is.na(president_trust))
small_argentina <- subset(small_argentina, !is.na(muni_trust))
small_argentina_us <- subset(small_argentina, !is.na(us_trust_clean))
small_argentina_china <- subset(small_argentina, !is.na(china_trust_clean))


### Make small DF with means and SDs 
argentina_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(argentina_summary) <- c("institution")

argentina_summary$mean <- ifelse(argentina_summary$institution == "Army", mean(small_argentina$army_trust), 
                                 ifelse(argentina_summary$institution == "President", mean(small_argentina$president_trust),
                                        ifelse(argentina_summary$institution == "Mayor", mean(small_argentina$muni_trust),
                                               ifelse(argentina_summary$institution == "China", mean(small_argentina_china$china_trust),
                                                      ifelse(argentina_summary$institution == "United States", mean(small_argentina_us$us_trust), 0))))) 

argentina_summary$se <- ifelse(argentina_summary$institution == "Army", sd(small_argentina$army_trust)/sqrt(length(small_argentina$army_trust)), 
                               ifelse(argentina_summary$institution == "President", sd(small_argentina$president_trust)/sqrt(length(small_argentina$president_trust)),
                                      ifelse(argentina_summary$institution == "Mayor", sd(small_argentina$muni_trust)/sqrt(length(small_argentina$muni_trust)),
                                             ifelse(argentina_summary$institution == "China", sd(small_argentina_china$china_trust)/sqrt(length(small_argentina_china$china_trust)),
                                                    ifelse(argentina_summary$institution == "United States", sd(small_argentina_us$us_trust)/sqrt(length(small_argentina_us$us_trust)), 0))))) 

ggplot(argentina_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="lightskyblue1", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Argentina",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))

### Brazil
small_brazil <- data.frame(brazil_2019$pais, brazil_2019$b12, brazil_2019$b21a, brazil_2019$b32, brazil_2019$mil10a, brazil_2019$mil10e) 
colnames(small_brazil) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_brazil$china_trust_clean <- 5 - small_brazil$china_trust
small_brazil$us_trust_clean <- 5 - small_brazil$us_trust 
small_brazil$army_trust <- (4*(small_brazil$army_trust))/7 
small_brazil$president_trust <- (4*(small_brazil$president_trust))/7 
small_brazil$muni_trust <- (4*(small_brazil$muni_trust))/7 

small_brazil$army_trust <- ifelse(small_brazil$army_trust < 1, 1, small_brazil$army_trust)
small_brazil$president_trust <- ifelse(small_brazil$president_trust < 1, 1, small_brazil$president_trust)
small_brazil$muni_trust <- ifelse(small_brazil$muni_trust < 1, 1, small_brazil$muni_trust)

small_brazil$us_trust <- NULL
small_brazil$china_trust <- NULL
small_brazil$pais <- "Brazil"
small_brazil$country <- NULL  



small_brazil <- subset(small_brazil, !is.na(army_trust))
small_brazil <- subset(small_brazil, !is.na(president_trust))
small_brazil <- subset(small_brazil, !is.na(muni_trust))
small_brazil_us <- subset(small_brazil, !is.na(us_trust_clean))
small_brazil_china <- subset(small_brazil, !is.na(china_trust_clean))


### Make small DF with means and SDs 
brazil_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(brazil_summary) <- c("institution")

brazil_summary$mean <- ifelse(brazil_summary$institution == "Army", mean(small_brazil$army_trust), 
                              ifelse(brazil_summary$institution == "President", mean(small_brazil$president_trust),
                                     ifelse(brazil_summary$institution == "Mayor", mean(small_brazil$muni_trust),
                                            ifelse(brazil_summary$institution == "China", mean(small_brazil_china$china_trust),
                                                   ifelse(brazil_summary$institution == "United States", mean(small_brazil_us$us_trust), 0))))) 

brazil_summary$se <- ifelse(brazil_summary$institution == "Army", sd(small_brazil$army_trust)/sqrt(length(small_brazil$army_trust)), 
                            ifelse(brazil_summary$institution == "President", sd(small_brazil$president_trust)/sqrt(length(small_brazil$president_trust)),
                                   ifelse(brazil_summary$institution == "Mayor", sd(small_brazil$muni_trust)/sqrt(length(small_brazil$muni_trust)),
                                          ifelse(brazil_summary$institution == "China", sd(small_brazil_china$china_trust)/sqrt(length(small_brazil_china$china_trust)),
                                                 ifelse(brazil_summary$institution == "United States", sd(small_brazil_us$us_trust)/sqrt(length(small_brazil_us$us_trust)), 0))))) 

ggplot(brazil_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="lightskyblue3", alpha=0.8) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Brazil",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))



### Chile
small_chile <- data.frame(chile_2019$pais, chile_2019$b12, chile_2019$b21a, chile_2019$b32, chile_2019$mil10a, chile_2019$mil10e) 
colnames(small_chile) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_chile$china_trust_clean <- 5 - small_chile$china_trust
small_chile$us_trust_clean <- 5 - small_chile$us_trust 
small_chile$army_trust <- (4*(small_chile$army_trust))/7 
small_chile$president_trust <- (4*(small_chile$president_trust))/7 
small_chile$muni_trust <- (4*(small_chile$muni_trust))/7 

small_chile$army_trust <- ifelse(small_chile$army_trust < 1, 1, small_chile$army_trust)
small_chile$president_trust <- ifelse(small_chile$president_trust < 1, 1, small_chile$president_trust)
small_chile$muni_trust <- ifelse(small_chile$muni_trust < 1, 1, small_chile$muni_trust)

small_chile$us_trust <- NULL
small_chile$china_trust <- NULL
small_chile$pais <- "Chile"
small_chile$country <- NULL  

small_chile <- subset(small_chile, !is.na(army_trust))
small_chile <- subset(small_chile, !is.na(president_trust))
small_chile <- subset(small_chile, !is.na(muni_trust))
small_chile_us <- subset(small_chile, !is.na(us_trust_clean))
small_chile_china <- subset(small_chile, !is.na(china_trust_clean))


### Make small DF with means and SDs 
chile_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(chile_summary) <- c("institution")

chile_summary$mean <- ifelse(chile_summary$institution == "Army", mean(small_chile$army_trust), 
                             ifelse(chile_summary$institution == "President", mean(small_chile$president_trust),
                                    ifelse(chile_summary$institution == "Mayor", mean(small_chile$muni_trust),
                                           ifelse(chile_summary$institution == "China", mean(small_chile_china$china_trust),
                                                  ifelse(chile_summary$institution == "United States", mean(small_chile_us$us_trust), 0))))) 

chile_summary$se <- ifelse(chile_summary$institution == "Army", sd(small_chile$army_trust)/sqrt(length(small_chile$army_trust)), 
                           ifelse(chile_summary$institution == "President", sd(small_chile$president_trust)/sqrt(length(small_chile$president_trust)),
                                  ifelse(chile_summary$institution == "Mayor", sd(small_chile$muni_trust)/sqrt(length(small_chile$muni_trust)),
                                         ifelse(chile_summary$institution == "China", sd(small_chile_china$china_trust)/sqrt(length(small_chile_china$china_trust)),
                                                ifelse(chile_summary$institution == "United States", sd(small_chile_us$us_trust)/sqrt(length(small_chile_us$us_trust)), 0))))) 

ggplot(chile_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="steelblue1", alpha=0.8) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Chile",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Colombia
small_colombia <- data.frame(colombia_2019$pais, colombia_2019$b12, colombia_2019$b21a, colombia_2019$b32, colombia_2019$mil10a, colombia_2019$mil10e) 
colnames(small_colombia) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_colombia$china_trust_clean <- 5 - small_colombia$china_trust
small_colombia$us_trust_clean <- 5 - small_colombia$us_trust 
small_colombia$army_trust <- (4*(small_colombia$army_trust))/7 
small_colombia$president_trust <- (4*(small_colombia$president_trust))/7 
small_colombia$muni_trust <- (4*(small_colombia$muni_trust))/7 

small_colombia$army_trust <- ifelse(small_colombia$army_trust < 1, 1, small_colombia$army_trust)
small_colombia$president_trust <- ifelse(small_colombia$president_trust < 1, 1, small_colombia$president_trust)
small_colombia$muni_trust <- ifelse(small_colombia$muni_trust < 1, 1, small_colombia$muni_trust)

small_colombia$us_trust <- NULL
small_colombia$china_trust <- NULL
small_colombia$pais <- "Colombia"
small_colombia$country <- NULL  

small_colombia <- subset(small_colombia, !is.na(army_trust))
small_colombia <- subset(small_colombia, !is.na(president_trust))
small_colombia <- subset(small_colombia, !is.na(muni_trust))
small_colombia_us <- subset(small_colombia, !is.na(us_trust_clean))
small_colombia_china <- subset(small_colombia, !is.na(china_trust_clean))


### Make small DF with means and SDs 
colombia_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(colombia_summary) <- c("institution")

colombia_summary$mean <- ifelse(colombia_summary$institution == "Army", mean(small_colombia$army_trust), 
                                ifelse(colombia_summary$institution == "President", mean(small_colombia$president_trust),
                                       ifelse(colombia_summary$institution == "Mayor", mean(small_colombia$muni_trust),
                                              ifelse(colombia_summary$institution == "China", mean(small_colombia_china$china_trust),
                                                     ifelse(colombia_summary$institution == "United States", mean(small_colombia_us$us_trust), 0))))) 

colombia_summary$se <- ifelse(colombia_summary$institution == "Army", sd(small_colombia$army_trust)/sqrt(length(small_colombia$army_trust)), 
                              ifelse(colombia_summary$institution == "President", sd(small_colombia$president_trust)/sqrt(length(small_colombia$president_trust)),
                                     ifelse(colombia_summary$institution == "Mayor", sd(small_colombia$muni_trust)/sqrt(length(small_colombia$muni_trust)),
                                            ifelse(colombia_summary$institution == "China", sd(small_colombia_china$china_trust)/sqrt(length(small_colombia_china$china_trust)),
                                                   ifelse(colombia_summary$institution == "United States", sd(small_colombia_us$us_trust)/sqrt(length(small_colombia_us$us_trust)), 0))))) 

ggplot(colombia_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="steelblue3", alpha=0.8) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Colombia",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Mexico
small_mexico <- data.frame(mexico_2019$pais, mexico_2019$b12, mexico_2019$b21a, mexico_2019$b32, mexico_2019$mil10a, mexico_2019$mil10e) 
colnames(small_mexico) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_mexico$china_trust_clean <- 5 - small_mexico$china_trust
small_mexico$us_trust_clean <- 5 - small_mexico$us_trust 
small_mexico$army_trust <- (4*(small_mexico$army_trust))/7 
small_mexico$president_trust <- (4*(small_mexico$president_trust))/7 
small_mexico$muni_trust <- (4*(small_mexico$muni_trust))/7 


small_mexico$army_trust <- ifelse(small_mexico$army_trust < 1, 1, small_mexico$army_trust)
small_mexico$president_trust <- ifelse(small_mexico$president_trust < 1, 1, small_mexico$president_trust)
small_mexico$muni_trust <- ifelse(small_mexico$muni_trust < 1, 1, small_mexico$muni_trust) 

small_mexico$us_trust <- NULL
small_mexico$china_trust <- NULL
small_mexico$pais <- "Mexico"
small_mexico$country <- NULL  


small_mexico <- subset(small_mexico, !is.na(army_trust))
small_mexico <- subset(small_mexico, !is.na(president_trust))
small_mexico <- subset(small_mexico, !is.na(muni_trust))
small_mexico_us <- subset(small_mexico, !is.na(us_trust_clean))
small_mexico_china <- subset(small_mexico, !is.na(china_trust_clean))


### Make small DF with means and SDs 
mexico_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(mexico_summary) <- c("institution")

mexico_summary$mean <- ifelse(mexico_summary$institution == "Army", mean(small_mexico$army_trust), 
                              ifelse(mexico_summary$institution == "President", mean(small_mexico$president_trust),
                                     ifelse(mexico_summary$institution == "Mayor", mean(small_mexico$muni_trust),
                                            ifelse(mexico_summary$institution == "China", mean(small_mexico_china$china_trust),
                                                   ifelse(mexico_summary$institution == "United States", mean(small_mexico_us$us_trust), 0))))) 

mexico_summary$se <- ifelse(mexico_summary$institution == "Army", sd(small_mexico$army_trust)/sqrt(length(small_mexico$army_trust)), 
                            ifelse(mexico_summary$institution == "President", sd(small_mexico$president_trust)/sqrt(length(small_mexico$president_trust)),
                                   ifelse(mexico_summary$institution == "Mayor", sd(small_mexico$muni_trust)/sqrt(length(small_mexico$muni_trust)),
                                          ifelse(mexico_summary$institution == "China", sd(small_mexico_china$china_trust)/sqrt(length(small_mexico_china$china_trust)),
                                                 ifelse(mexico_summary$institution == "United States", sd(small_mexico_us$us_trust)/sqrt(length(small_mexico_us$us_trust)), 0))))) 

ggplot(mexico_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="mediumblue", alpha=0.8) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Mexico",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))



### Peru 
small_peru <- data.frame(peru_2019$pais, peru_2019$b12, peru_2019$b21a, peru_2019$b32, peru_2019$mil10a, peru_2019$mil10e) 


colnames(small_peru) <- c("country", "army_trust", "president_trust", "muni_trust", "china_trust", "us_trust")
small_peru$china_trust_clean <- 5 - small_peru$china_trust
small_peru$us_trust_clean <- 5 - small_peru$us_trust 
small_peru$army_trust <- (4*(small_peru$army_trust))/7 
small_peru$president_trust <- (4*(small_peru$president_trust))/7 
small_peru$muni_trust <- (4*(small_peru$muni_trust))/7 

small_peru$army_trust <- ifelse(small_peru$army_trust < 1, 1, small_peru$army_trust)
small_peru$president_trust <- ifelse(small_peru$president_trust < 1, 1, small_peru$president_trust)
small_peru$muni_trust <- ifelse(small_peru$muni_trust < 1, 1, small_peru$muni_trust)

small_peru$us_trust <- NULL
small_peru$china_trust <- NULL
small_peru$pais <- "Peru"
small_peru$country <- NULL  

# Clean to make pllot 
small_peru <- subset(small_peru, !is.na(army_trust))
small_peru <- subset(small_peru, !is.na(president_trust))
small_peru <- subset(small_peru, !is.na(muni_trust))
small_peru_us <- subset(small_peru, !is.na(us_trust_clean))
small_peru_china <- subset(small_peru, !is.na(china_trust_clean))


### Make small DF with means and SDs 
peru_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(peru_summary) <- c("institution")

peru_summary$mean <- ifelse(peru_summary$institution == "Army", mean(small_peru$army_trust), 
                            ifelse(peru_summary$institution == "President", mean(small_peru$president_trust),
                                   ifelse(peru_summary$institution == "Mayor", mean(small_peru$muni_trust),
                                          ifelse(peru_summary$institution == "China", mean(small_peru_china$china_trust),
                                                 ifelse(peru_summary$institution == "United States", mean(small_peru_us$us_trust), 0))))) 

peru_summary$se <- ifelse(peru_summary$institution == "Army", sd(small_peru$army_trust)/sqrt(length(small_peru$army_trust)), 
                          ifelse(peru_summary$institution == "President", sd(small_peru$president_trust)/sqrt(length(small_peru$president_trust)),
                                 ifelse(peru_summary$institution == "Mayor", sd(small_peru$muni_trust)/sqrt(length(small_peru$muni_trust)),
                                        ifelse(peru_summary$institution == "China", sd(small_peru_china$china_trust)/sqrt(length(small_peru_china$china_trust)),
                                               ifelse(peru_summary$institution == "United States", sd(small_peru_us$us_trust)/sqrt(length(small_peru_us$us_trust)), 0))))) 

ggplot(peru_summary) +  
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="navy", alpha=0.8) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="LAPOP (General Population) Trust - Peru",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4)) 

rm(argentina_2019, brazil_2019, colombia_2019, chile_2019, mexico_2019, peru_2019, argentina_summary, brazil_summary, chile_summary,
   colombia_summary, mexico_summary, peru_summary, small_argentina, small_brazil, small_chile, small_colombia, small_mexico, small_peru)  

#### Hesitancy Plots - Our Survey ####
hesitancy_wide <- read_dta("vaccine_wide.dta")
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_country_govs_1) & hesitancy_wide$trust_country_govs_1 > 0) # China 
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_country_govs_2) & hesitancy_wide$trust_country_govs_2 > 0) # US Trump 
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_country_govs_3) & hesitancy_wide$trust_country_govs_3 > 0) # US China 
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_orgs_3) & hesitancy_wide$trust_orgs_3 > 0) # Army 
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_persons_insts_1) & hesitancy_wide$trust_persons_insts_1 > 0) # President 
hesitancy_wide <- subset(hesitancy_wide, !is.na(hesitancy_wide$trust_persons_insts_2)  & hesitancy_wide$trust_persons_insts_2 > 0) # Mayor     
hesitancy_wide$us_trust <- (hesitancy_wide$trust_country_govs_2 + hesitancy_wide$trust_country_govs_3)/2

## Subset into countries 
argentina <- subset(hesitancy_wide, country == "Argentina")
brazil <- subset(hesitancy_wide, country == "Brasil")
chile <- subset(hesitancy_wide, country == "Chile")
colombia <- subset(hesitancy_wide, country == "Colombia")
mexico <- subset(hesitancy_wide, country == "México")
peru <- subset(hesitancy_wide, country == "Perú")


### Make small data frame with means and standard deviations -- Argentina 
argentina_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(argentina_hes_summary) <- c("institution")

argentina_hes_summary$mean <- ifelse(argentina_hes_summary$institution == "Army", mean(argentina$trust_orgs_3), 
                                     ifelse(argentina_hes_summary$institution == "President", mean(argentina$trust_persons_insts_1),
                                            ifelse(argentina_hes_summary$institution == "Mayor", mean(argentina$trust_persons_insts_2),
                                                   ifelse(argentina_hes_summary$institution == "China", mean(argentina$trust_country_govs_1),
                                                          ifelse(argentina_hes_summary$institution == "United States", mean(argentina$us_trust), 0)))))  

argentina_hes_summary$se <- ifelse(argentina_hes_summary$institution == "Army", sd(argentina$trust_orgs_3)/sqrt(length(argentina$trust_orgs_3)), 
                                   ifelse(argentina_hes_summary$institution == "President", sd(argentina$trust_persons_insts_1)/sqrt(length(argentina$trust_persons_insts_1)),
                                          ifelse(argentina_hes_summary$institution == "Mayor", sd(argentina$trust_persons_insts_2)/sqrt(length(argentina$trust_persons_insts_2)),
                                                 ifelse(argentina_hes_summary$institution == "China", sd(argentina$trust_country_govs_1)/sqrt(length(argentina$trust_country_govs_1)),
                                                        ifelse(argentina_hes_summary$institution == "United States", sd(argentina$us_trust)/sqrt(length(argentina$us_trust)), 0))))) 

ggplot(argentina_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="lightskyblue1", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Argentina",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Make small data frame with means and standard deviations -- Brazil 
brazil_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(brazil_hes_summary) <- c("institution")

brazil_hes_summary$mean <- ifelse(brazil_hes_summary$institution == "Army", mean(brazil$trust_orgs_3), 
                                  ifelse(brazil_hes_summary$institution == "President", mean(brazil$trust_persons_insts_1),
                                         ifelse(brazil_hes_summary$institution == "Mayor", mean(brazil$trust_persons_insts_2),
                                                ifelse(brazil_hes_summary$institution == "China", mean(brazil$trust_country_govs_1),
                                                       ifelse(brazil_hes_summary$institution == "United States", mean(brazil$us_trust), 0)))))  

brazil_hes_summary$se <- ifelse(brazil_hes_summary$institution == "Army", sd(brazil$trust_orgs_3)/sqrt(length(brazil$trust_orgs_3)), 
                                ifelse(brazil_hes_summary$institution == "President", sd(brazil$trust_persons_insts_1)/sqrt(length(brazil$trust_persons_insts_1)),
                                       ifelse(brazil_hes_summary$institution == "Mayor", sd(brazil$trust_persons_insts_2)/sqrt(length(brazil$trust_persons_insts_2)),
                                              ifelse(brazil_hes_summary$institution == "China", sd(brazil$trust_country_govs_1)/sqrt(length(brazil$trust_country_govs_1)),
                                                     ifelse(brazil_hes_summary$institution == "United States", sd(brazil$us_trust)/sqrt(length(brazil$us_trust)), 0))))) 

ggplot(brazil_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="lightskyblue3", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Brazil",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Make small data frame with means and standard deviations -- Chile 
chile_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(chile_hes_summary) <- c("institution")

chile_hes_summary$mean <- ifelse(chile_hes_summary$institution == "Army", mean(chile$trust_orgs_3), 
                                 ifelse(chile_hes_summary$institution == "President", mean(chile$trust_persons_insts_1),
                                        ifelse(chile_hes_summary$institution == "Mayor", mean(chile$trust_persons_insts_2),
                                               ifelse(chile_hes_summary$institution == "China", mean(chile$trust_country_govs_1),
                                                      ifelse(chile_hes_summary$institution == "United States", mean(chile$us_trust), 0)))))  

chile_hes_summary$se <- ifelse(chile_hes_summary$institution == "Army", sd(chile$trust_orgs_3)/sqrt(length(chile$trust_orgs_3)), 
                               ifelse(chile_hes_summary$institution == "President", sd(chile$trust_persons_insts_1)/sqrt(length(chile$trust_persons_insts_1)),
                                      ifelse(chile_hes_summary$institution == "Mayor", sd(chile$trust_persons_insts_2)/sqrt(length(chile$trust_persons_insts_2)),
                                             ifelse(chile_hes_summary$institution == "China", sd(chile$trust_country_govs_1)/sqrt(length(chile$trust_country_govs_1)),
                                                    ifelse(chile_hes_summary$institution == "United States", sd(chile$us_trust)/sqrt(length(chile$us_trust)), 0))))) 

ggplot(chile_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="steelblue1", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Chile",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Make small data frame with means and standard deviations -- Colombia
colombia_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(colombia_hes_summary) <- c("institution")

colombia_hes_summary$mean <- ifelse(colombia_hes_summary$institution == "Army", mean(colombia$trust_orgs_3), 
                                    ifelse(colombia_hes_summary$institution == "President", mean(colombia$trust_persons_insts_1),
                                           ifelse(colombia_hes_summary$institution == "Mayor", mean(colombia$trust_persons_insts_2),
                                                  ifelse(colombia_hes_summary$institution == "China", mean(colombia$trust_country_govs_1),
                                                         ifelse(colombia_hes_summary$institution == "United States", mean(colombia$us_trust), 0)))))  

colombia_hes_summary$se <- ifelse(colombia_hes_summary$institution == "Army", sd(colombia$trust_orgs_3)/sqrt(length(colombia$trust_orgs_3)), 
                                  ifelse(colombia_hes_summary$institution == "President", sd(colombia$trust_persons_insts_1)/sqrt(length(colombia$trust_persons_insts_1)),
                                         ifelse(colombia_hes_summary$institution == "Mayor", sd(colombia$trust_persons_insts_2)/sqrt(length(colombia$trust_persons_insts_2)),
                                                ifelse(colombia_hes_summary$institution == "China", sd(colombia$trust_country_govs_1)/sqrt(length(colombia$trust_country_govs_1)),
                                                       ifelse(colombia_hes_summary$institution == "United States", sd(colombia$us_trust)/sqrt(length(colombia$us_trust)), 0))))) 

ggplot(colombia_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="steelblue3", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Colombia",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


### Make small data frame with means and standard deviations -- Mexico
mexico_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(mexico_hes_summary) <- c("institution")

mexico_hes_summary$mean <- ifelse(mexico_hes_summary$institution == "Army", mean(mexico$trust_orgs_3), 
                                  ifelse(mexico_hes_summary$institution == "President", mean(mexico$trust_persons_insts_1),
                                         ifelse(mexico_hes_summary$institution == "Mayor", mean(mexico$trust_persons_insts_2),
                                                ifelse(mexico_hes_summary$institution == "China", mean(mexico$trust_country_govs_1),
                                                       ifelse(mexico_hes_summary$institution == "United States", mean(mexico$us_trust), 0)))))  

mexico_hes_summary$se <- ifelse(mexico_hes_summary$institution == "Army", sd(mexico$trust_orgs_3)/sqrt(length(mexico$trust_orgs_3)), 
                                ifelse(mexico_hes_summary$institution == "President", sd(mexico$trust_persons_insts_1)/sqrt(length(mexico$trust_persons_insts_1)),
                                       ifelse(mexico_hes_summary$institution == "Mayor", sd(mexico$trust_persons_insts_2)/sqrt(length(mexico$trust_persons_insts_2)),
                                              ifelse(mexico_hes_summary$institution == "China", sd(mexico$trust_country_govs_1)/sqrt(length(mexico$trust_country_govs_1)),
                                                     ifelse(mexico_hes_summary$institution == "United States", sd(mexico$us_trust)/sqrt(length(mexico$us_trust)), 0))))) 

ggplot(mexico_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="mediumblue", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Mexico",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))

### Make small data frame with means and standard deviations -- Peru 
peru_hes_summary <- as.data.frame(c("Army", "President", "Mayor", "China", "United States"))
colnames(peru_hes_summary) <- c("institution")

peru_hes_summary$mean <- ifelse(peru_hes_summary$institution == "Army", mean(peru$trust_orgs_3), 
                                ifelse(peru_hes_summary$institution == "President", mean(peru$trust_persons_insts_1),
                                       ifelse(peru_hes_summary$institution == "Mayor", mean(peru$trust_persons_insts_2),
                                              ifelse(peru_hes_summary$institution == "China", mean(peru$trust_country_govs_1),
                                                     ifelse(peru_hes_summary$institution == "United States", mean(peru$us_trust), 0)))))  

peru_hes_summary$se <- ifelse(peru_hes_summary$institution == "Army", sd(peru$trust_orgs_3)/sqrt(length(peru$trust_orgs_3)), 
                              ifelse(peru_hes_summary$institution == "President", sd(peru$trust_persons_insts_1)/sqrt(length(peru$trust_persons_insts_1)),
                                     ifelse(peru_hes_summary$institution == "Mayor", sd(peru$trust_persons_insts_2)/sqrt(length(peru$trust_persons_insts_2)),
                                            ifelse(peru_hes_summary$institution == "China", sd(peru$trust_country_govs_1)/sqrt(length(peru$trust_country_govs_1)),
                                                   ifelse(peru_hes_summary$institution == "United States", sd(peru$us_trust)/sqrt(length(peru$us_trust)), 0))))) 

ggplot(peru_hes_summary) +
  geom_bar(aes(x=institution, y=mean), stat="identity", fill="navy", alpha=1.0) +
  geom_errorbar( aes(x=institution, ymin=mean-se, ymax=mean+se), width=0.4, colour="orange", alpha=0.9, size=1.3) +
  labs(title="Our Survey (Hesitant Population) Trust - Peru",
       x ="", y = "Mean Trust") +
  scale_y_continuous(limits = c(0,4))


## Marginal means plot (Appendix Figure A1)
library(cregg)

hesitancy_long_mm <- hesitancy_long %>%
  mutate(
    distribution_enc_new = case_when(
      distrib_army == 1 ~ "Armed Forces",
      distrib_health == 1 ~ "National Health System",
      distrib_ngo == 1 ~ "Civil Society"
  ),
    endorser_enc_new = case_when(
      endorse_pres == 1 ~ "President",
      endorse_mayor == 1 ~ "Mayor",
      endorse_medic == 1 ~ "Medical Association",
      endorse_relig == 1 ~ "Religious Leader",
      endorse_leftnews == 1 ~ "Left Newspaper",
      endorse_rightnews == 1 ~ "Right Newspaper"
  ),
  vaccine_enc_new = case_when(
    vaccine_ == "una vacuna" ~ "No Producer Information",
    vaccine_ == "uma vacuna" ~ "No Producer Information",
    vaccine_gamaleya == 1 ~ "Gamaleya",
    vaccine_astrazeneca == 1 ~ "Astrazeneca",
    vaccine_pfizer == 1 ~ "Pfizer",
    vaccine_sinovac == 1 ~ "Sinovac"
  ),
  efficacy_enc_new = case_when(
    efficacy_ == "." ~ "No Efficacy Information",
    efficacy_50 == 1 ~ "50% (Sinovac)",
    efficacy_70 == 1 ~ "70% (Astrazeneca)",
    efficacy_78 == 1 ~ "78% (Sinovac)",
    efficacy_91 == 1 ~ "91% (Gamaleya)",
    efficacy_95 == 1 ~ "95% (Pfizer)"
  ),
  uptake_enc_new = case_when(
    uptake_ == "." ~ "No Uptake Information",
    uptake_1 == 1 ~ "1%",
    uptake_25 == 1 ~ "25%",
    uptake_50 == 1 ~ "50%",
    uptake_75 == 1 ~ "75%",
  )) %>%
  mutate(distribution_fac = as_factor(distribution_enc_new),
         endorser_fac     = as_factor(endorser_enc_new),
         vaccine_fac      = as_factor(vaccine_enc_new),
         efficacy_fac     = as_factor(efficacy_enc_new),
         uptake_fac       = as_factor(uptake_enc_new),
         round_fac        = as_factor(round),
         responseid_fac   = as_factor(responseid)) %>%
  mutate(distribution_fac = factor(distribution_fac, levels = rev(c(
                                                                "Civil Society",
                                                                "Armed Forces",
                                                                "National Health System"))),
         endorser_fac     = factor(endorser_fac, levels = rev(c(
                                                            "President",
                                                            "Mayor",
                                                            "Right Newspaper",
                                                            "Left Newspaper",
                                                            "Religious Leader",
                                                            "Medical Association"
                                                            ))),
         vaccine_fac      = factor(vaccine_fac, levels = rev(c(
                                                           "Astrazeneca",
                                                           "Gamaleya",
                                                           "Pfizer",
                                                           "Sinovac",
                                                           "No Producer Information"))),
         efficacy_fac     = factor(efficacy_fac, levels = rev(c(
                                                            "95% (Pfizer)",
                                                            "91% (Gamaleya)",
                                                            "78% (Sinovac)",
                                                            "70% (Astrazeneca)",
                                                            "50% (Sinovac)",
                                                            "No Efficacy Information"))),
         uptake_fac       = factor(uptake_fac, levels = rev(c(
                                                          "75%",
                                                          "50%",
                                                          "25%",
                                                          "1%",
                                                          "No Uptake Information"))))

mm_formula <- willing_vaccine ~ distribution_fac + endorser_fac + vaccine_fac + efficacy_fac + uptake_fac + round_fac + responseid_fac

mm_model1 <- mm(data = hesitancy_long_mm,
                formula = mm_formula,
                id = ~ responseid,
                weights = ~ w_conjoint,
                feature_order = c("vaccine_fac",
                                  "uptake_fac",
                                  "endorser_fac",
                                  "efficacy_fac",
                                  "distribution_fac",
                                  "round_fac",
                                  "responseid_fac"))

save(mm_model1, file = "marginal_means_model1_new.Rdata")

mm_model1 <- mm_model1 %>%
  filter(feature != "round_fac" & feature != "Response ID") %>%
  mutate(feature = case_when(
      feature == "distribution_fac" ~ "Distributor",
      feature == "endorser_fac" ~ "Endorser",
      feature == "vaccine_fac" ~ "Producer",
      feature == "efficacy_fac" ~ "Efficacy",
      feature == "uptake_fac" ~ "Uptake",
    ),
    feature = factor(feature, levels = c("Distributor", "Endorser", "Producer", "Efficacy", "Uptake")))

mm_model1_plot <- plot(mm_model1) +
  ggtitle("Willingness to Take This Vaccine") +
  theme(axis.text.y = element_text(face = rev(
    c("bold",
      rep("plain", 3),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5)))))

mm_formula <- quickly_post_1_text_reversed ~ distribution_fac + endorser_fac + vaccine_fac + efficacy_fac + uptake_fac + round_fac + responseid_fac

mm_model2 <- mm(data = hesitancy_long_mm,
                formula = mm_formula,
                id = ~ responseid,
                weights = ~ w_conjoint,
                feature_order = c("vaccine_fac",
                                  "uptake_fac",
                                  "endorser_fac",
                                  "efficacy_fac",
                                  "distribution_fac",
                                  "round_fac",
                                  "responseid_fac"))

save(mm_model2, file = "marginal_means_model2.Rdata")

mm_model2 <- mm_model2 %>%
    filter(feature != "round_fac" & feature != "Response ID") %>%
    mutate(feature = case_when(
      feature == "distribution_fac" ~ "Distributor",
      feature == "endorser_fac" ~ "Endorser",
      feature == "vaccine_fac" ~ "Producer",
      feature == "efficacy_fac" ~ "Efficacy",
      feature == "uptake_fac" ~ "Uptake",
    ),
    feature = factor(feature, levels = c("Distributor", "Endorser", "Producer", "Efficacy", "Uptake")))

mm_model2_plot <- plot(mm_model2) +
  ggtitle("Months Would Wait Before Taking this Vaccine (Reversed Scale)") +
  theme(axis.text.y = element_text(face = rev(
    c("bold",
      rep("plain", 3),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5),
      "bold",
      rep("plain", 6),
      "bold",
      rep("plain", 5)))))

pdf("mm_willing.pdf")
print(mm_model1_plot)
dev.off()

pdf("mm_quickly.pdf")
print(mm_model2_plot)
dev.off()

## Tables with N in each condition

n_summary <- mm_model1 %>%
  select(feature, level) %>%
  rename(Feature = feature,
         Level = level)

groups <- c(quo(distribution_fac),
            quo(endorser_fac),
            quo(vaccine_fac),
            quo(efficacy_fac),
            quo(uptake_fac))

group_n <- lapply(groups, function(i)
  hesitancy_long_mm %>%
    group_by(!!i) %>%
    count() %>%
    rename(Level = !!i)
)

group_n <- bind_rows(group_n)

n_summary <- left_join(n_summary, group_n) %>%
  rename(N = n)

library(xtable)
print(xtable(n_summary), include.rownames=FALSE, file = "n_summary.tex")

